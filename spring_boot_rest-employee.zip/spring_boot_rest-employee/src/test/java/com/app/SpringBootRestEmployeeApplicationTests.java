package com.app;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import static org.junit.jupiter.api.Assertions.assertEquals;

import com.app.dao.EmployeeRepository;
import com.app.pojos.Employee;
import com.app.service.IEmployeeService;

@SpringBootTest
class SpringBootRestEmployeeApplicationTests {
	@Autowired
	private EmployeeRepository empRepo;
	
	@Autowired
	private IEmployeeService empService;

	@Test
	void contextLoads() {
		List<Employee> allEmoloyee = empService.getAllEmployee();
		assertEquals(0,allEmoloyee.size());
	
	}
	
	@Test
	public void saveEmployee() throws Exception {
		Employee emp = new Employee("Ajit","Dwivedi","dwivediajit91@gmail.com","Pune","Developers",new SimpleDateFormat("dd/MM/yyyy").parse("02/04/2022"),800000);
		Employee emp1 = empRepo.save(emp);
		assertEquals(1,emp1.getId());
	}
	


}
