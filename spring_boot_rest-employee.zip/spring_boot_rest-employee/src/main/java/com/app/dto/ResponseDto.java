package com.app.dto;

public class ResponseDto {
	private String msg;
	
	public ResponseDto(String msg) {
		this.msg = msg;
	}

	public ResponseDto() {
		super();
		
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}
	
	
	
	

}
