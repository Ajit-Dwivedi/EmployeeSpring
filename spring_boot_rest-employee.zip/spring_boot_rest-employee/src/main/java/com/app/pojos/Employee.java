package com.app.pojos;

import java.util.Date;

import javax.persistence.*;

@Entity
@Table(name="employee")
public class Employee extends BaseEntity{
	
	@Column(length=30)
	private String firstName;
	@Column(length=30)
	private String lastName;
	@Column(length=30,unique=true)
	private String email;
	
	@Column(length=30)
	private String location;
	@Column(length=30)
	private String department;
	private Date joinDate;	
	private double salary;
	
	public Employee() {
		super();
		
	}

	public Employee(String firstName, String lastName, String email, String location, String department, Date joinDate,
			double salary) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
		this.location = location;
		this.department = department;
		this.joinDate = joinDate;
		this.salary = salary;
		
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public Date getJoinDate() {
		return joinDate;
	}

	public void setJoinDate(Date joinDate) {
		this.joinDate = joinDate;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	
	@Override
	public String toString() {
		return "Employee [firstName=" + firstName + ", lastName=" + lastName + ", email=" + email + ", location="
				+ location + ", department=" + department + ", joinDate=" + joinDate + ", salary=" + salary + "]";
	}
	
	
	
	
	
	

}
