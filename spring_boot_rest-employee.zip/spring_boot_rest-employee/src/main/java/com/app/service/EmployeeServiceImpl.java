package com.app.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.dao.EmployeeRepository;
import com.app.pojos.Employee;

@Service
@Transactional
public class EmployeeServiceImpl implements IEmployeeService {
	
	@Autowired
	private EmployeeRepository empRepo;

	@Override
	public List<Employee> getAllEmployee() {
		
		return empRepo.findAll();
	}

	@Override
	public Employee saveEmp(Employee emp) {
		
		return empRepo.save(emp);
	}

	@Override
	public String deleteEmployee(Long empId) {
	//	Employee e = empRepo.findById(empId);
		empRepo.deleteById(empId);
		
	return "Employee Deleted succefully!!!!";
		
	}

}
