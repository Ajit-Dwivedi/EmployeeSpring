package com.app.service;

import java.util.List;
import com.app.pojos.Employee;


public interface IEmployeeService {
	List<Employee> getAllEmployee();
	Employee saveEmp(Employee emp);
	String deleteEmployee(Long empId);
}
